<?php

$searchDir=array(
  "dalvik",
  "dalvik/vm",
  "external/stlport/stlport",
  "bionic",
  "bionic/libstdc++/include",
  "system/core/include",
  "frameworks/native/include",
  "frameworks/base/include",
  "libnativehelper/include",
);
