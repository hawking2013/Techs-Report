<?php
// 目录是有次序的
$searchDir=array(
  "art",
  "art/runtime",
  "art/runtime/arch/arm",
  "art/runtime/entrypoints/quick",
  "external/gtest/include",
  "external/valgrind/main",
  "external/valgrind/main/include",
  "external/libcxx/include",
  "system/core/include",
  "frameworks/base/include",
  "frameworks/native/include",
  "libnativehelper/include",
  "libnativehelper/include/nativehelper",
  "bionic",
);
