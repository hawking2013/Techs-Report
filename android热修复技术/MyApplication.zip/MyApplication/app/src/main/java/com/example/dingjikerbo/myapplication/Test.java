package com.example.dingjikerbo.myapplication;

import android.util.Log;

import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.reflect.MethodUtils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Created by dingjikerbo on 16/1/1.
 */
public class Test {

    static {
        System.loadLibrary("test");
    }

    public static void hello() {
        Log.i("bush", "hello called");
    }

    public native static void showMethodFromReflect(Method method);
    public native static void showMethodFromSlot(Class<?> clazz, int slot);
    public native static void showMethodFromSig(Class<?> clazz, String methodName, String methodSig);
}
