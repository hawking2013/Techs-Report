package com.example.dingjikerbo.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.reflect.MethodUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Created by dingjikerbo on 16/1/1.
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showMethodFromReflect();
        showMethodFromSlot();
        showMethodFromSig();
    }

    private void showMethodFromReflect() {
        Method method = MethodUtils.getAccessibleMethod(Test.class, "hello");
        Test.showMethodFromReflect(method);
    }

    private void showMethodFromSlot() {
        Method method = MethodUtils.getAccessibleMethod(Test.class, "hello");
        Field field = FieldUtils.getField(Method.class, "slot", true);
        try {
            int slot = field.getInt(method);
            Test.showMethodFromSlot(Test.class, slot);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    private void showMethodFromSig() {
        Test.showMethodFromSig(Test.class, "hello", "()V");
    }
}
