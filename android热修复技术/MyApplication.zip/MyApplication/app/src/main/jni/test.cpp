//
// Created by dingjikerbo on 16/1/1.
//


#include <jni.h>
#include <stdlib.h>

#define ANDROID_SMP 0

#include "Dalvik.h"

JNIEXPORT jint
JNI_OnLoad(JavaVM *vm, void *reserved) {
	JNIEnv *env = NULL;
	jint result = -1;

	if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
		return result;
	}

	return JNI_VERSION_1_6;
}

void showMethodInfo(Method *method) {
	ALOGI("method: %p", method);
	ClassObject *classObject = method->clazz;
	ALOGD("clazz->descriptor: %s", classObject->descriptor);
	ALOGD("clazz->sourceFile: %s", classObject->sourceFile);
	ALOGD("name: %s", method->name);
	ALOGD("shorty: %s", method->shorty);
	ALOGD("accessFlags: %d", method->accessFlags);
}

extern "C" JNIEXPORT JNICALL void
Java_com_example_dingjikerbo_myapplication_Test_showMethodFromReflect(JNIEnv *env, jclass object, jobject methodObj) {
	Method* methodObject = (Method *) dvmDecodeIndirectRef(dvmThreadSelf(), methodObj);
	showMethodInfo(methodObject);
}

extern "C" JNIEXPORT JNICALL void
Java_com_example_dingjikerbo_myapplication_Test_showMethodFromSlot(JNIEnv *env, jclass clazz, jclass clazzToHook, jint slot) {
	ClassObject *clazzObject = (ClassObject *) dvmDecodeIndirectRef(dvmThreadSelf(), clazzToHook);
	Method *method = dvmSlotToMethod(clazzObject, slot);
	showMethodInfo(method);
}


extern "C" JNIEXPORT JNICALL void
Java_com_example_dingjikerbo_myapplication_Test_showMethodFromSig(JNIEnv *env, jclass object, jclass clazz, jstring methodName, jstring methodSig) {
	const char *_methodName = env->GetStringUTFChars(methodName, NULL);
	const char *_methodSig = env->GetStringUTFChars(methodSig, NULL);

	jmethodID methodId = env->GetMethodID(clazz, _methodName, _methodSig);
	if (methodId == NULL) {
		env->ExceptionClear();
		methodId = env->GetStaticMethodID(clazz, _methodName, _methodSig);
	}

	if (methodId != NULL) {
		Method *method = (Method *) methodId;
		showMethodInfo(method);
	}

	env->ReleaseStringUTFChars(methodName, _methodName);
	env->ReleaseStringUTFChars(methodSig, _methodSig);
}