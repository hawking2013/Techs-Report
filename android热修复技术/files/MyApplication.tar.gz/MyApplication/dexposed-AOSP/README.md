# dexposed-patch
-----------

project [Dexposed](https://github.com/alibaba/dexposed) submodule, Used to store the android source header files and libso files;
